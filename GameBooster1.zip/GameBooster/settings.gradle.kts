pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // API Xposed klasik (dipakai LSPosed). Kalau repo ini down, taruh api-82.jar di app/libs
        // lalu ganti dependensi di app/build.gradle.kts (lihat komentar di sana).
        maven("https://api.xposed.info/") {
            content { includeGroup("de.robv.android.xposed") }
        }
    }
}
rootProject.name = "GameBooster"
include(":app")
