# GameBooster (LSPosed module, AOSP 12+)

Module framework untuk prioritas & efisiensi resource saat main game. Target: AOSP / LineageOS / crDroid / Pixel (Android 12 – 16).

## Cara kerja

```
UI app ──broadcast (signature permission)──▶ system_server (module)
   ▲                                            │ simpan config di Settings.Global
   └────────────── status broadcast ◀───────────┘
```

Di `system_server` module memasang hook ringan di `TaskChangeNotificationController`
(`notifyTaskStackChanged`, `notifyTaskMovedToFront`). Setiap perubahan task:

1. Cek task paling atas (API publik `ActivityManager.getRunningTasks`).
2. Kalau package-nya ada di daftar → **profil GAME**. Kalau game tutup (jeda 2,5 dtk) → semua dikembalikan → **profil OVERALL**.

| Profil | Isi |
|---|---|
| OFF | Toggle mati. Semua dikembalikan. |
| OVERALL | Boost transisi UI singkat (Power HAL INTERACTION) saat pindah app / keluar game. Compaction RAM saat layar mati (maks. tiap 30 mnt). |
| GAME | Game Mode PERFORMANCE · Power HAL `GAME` + `GAME_LOADING` (12 dtk pertama) · naikkan nice thread render/tersibuk (-8 / -4, maks. 12 thread, hanya naik, dikembalikan saat keluar) · compaction RAM proses cache · opsional kunci refresh rate tertinggi. |

Layar mati saat game di depan → profil GAME dilepas, dipasang lagi saat layar nyala.

## Build

1. Buka folder ini di Android Studio (Ladybug/Meerkat atau lebih baru), tunggu sync.
2. Kalau sync gagal mengambil `de.robv.android.xposed:api:82`, unduh `api-82.jar`, taruh di `app/libs/`,
   lalu di `app/build.gradle.kts` ganti baris `compileOnly("de.robv...")` dengan `compileOnly(files("libs/api-82.jar"))`
   dan hapus blok `maven("https://api.xposed.info/")` di `settings.gradle.kts`.
3. Build → Run, atau `Build > Build APK(s)` (release sudah ditandatangani debug key).

## Pasang

1. Install APK.
2. LSPosed → Modules → GameBooster → aktifkan → scope **System Framework** (otomatis tercentang sebagai rekomendasi).
3. **Reboot**.
4. Buka app → kartu status harus menunjukkan "Module terhubung". Aktifkan toggle, tambahkan package game.

Kartu status juga menampilkan `notes` per fitur (`game_mode=ok, power_game=ok, compact=gagal-...`).
Itu cara cepat melihat fitur mana yang didukung ROM kamu.

## Debug

```
adb logcat -s GameBooster
```
Log LSPosed (Manager → Logs → Modules) berisi pesan `[GameBooster]` bila ada error.

## Batasan yang sengaja diambil

- **Tidak ada kill / force-stop** app background. Hasilnya app restart terus dan malah boros.
- **Tidak menurunkan nice proses background.** Android sudah menaruhnya di cgroup background; mengubah nice
  lewat `setThreadPriority` malah bisa memindahkan thread antar cgroup.
- **Tidak menyentuh `/dev/cpuset`, `uclamp`, governor.** Diblok SELinux untuk system_server. Butuh helper root, belum disertakan.
- Game Mode hanya berefek untuk app berkategori game. Di AOSP polos efeknya kecil kecuali ROM punya konfigurasi game_overlay.
- Hasil realistis: frame time lebih konsisten dan UI lebih responsif, bukan FPS tambahan.
- Hanya user 0 yang menerima status di UI.

## Kompatibilitas / jika ada fitur yang `gagal-...`

Semua panggilan internal memakai reflection dan terisolasi. Titik yang paling mungkin berubah antar ROM:

| Fitur | Titik internal |
|---|---|
| Deteksi game | `TaskChangeNotificationController.notifyTaskStackChanged` (fallback: polling 2 dtk) |
| Game Mode | `GameManager.getGameMode(String)` / `setGameMode(String,int)` |
| Power HAL | `PowerManagerInternal.setPowerMode/setPowerBoost`, konstanta `android.hardware.power.Mode/Boost` |
| Compaction | `ActivityManagerService.mOomAdjuster.mCachedAppOptimizer.compactAllSystem()` |
| Refresh rate | `Settings.System min_refresh_rate` |

Pindah ke libxposed API 100 nanti hanya mengubah `MainHook.kt` dan `Bootstrap.kt`/`installTaskHooks()`; sisanya tidak bergantung pada framework Xposed.
