plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.gamebooster.module"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.gamebooster.module"
        minSdk = 31          // Android 12+
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Biar APK release langsung bisa di-install tanpa keystore sendiri.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    // Jangan di-bundle: disediakan oleh LSPosed saat runtime.
    compileOnly("de.robv.android.xposed:api:82")
    // Alternatif kalau repo api.xposed.info tidak bisa diakses:
    // compileOnly(files("libs/api-82.jar"))

    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("com.google.android.material:material:1.12.0")
}
