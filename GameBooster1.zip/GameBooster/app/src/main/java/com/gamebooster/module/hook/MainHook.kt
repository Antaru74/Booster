package com.gamebooster.module.hook

import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.callbacks.XC_LoadPackage

/** Entry point LSPosed. Scope: System Framework ("android"). */
class MainHook : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != "android") return
        try {
            Bootstrap.install(lpparam.classLoader)
        } catch (t: Throwable) {
            XposedBridge.log("[GameBooster] install gagal: $t")
        }
    }
}
