package com.gamebooster.module.hook

import android.content.Context
import android.hardware.display.DisplayManager
import android.provider.Settings
import android.view.Display
import de.robv.android.xposed.XposedHelpers
import java.lang.reflect.InvocationTargetException

/**
 * Semua panggilan ke API internal Android. Seluruhnya reflection + try/catch:
 * kalau satu fitur tidak ada di ROM tertentu, fitur itu dilewati dan alasannya
 * muncul di kartu status app (field `notes`).
 */
class SystemHints(
    private val ctx: Context,
    private val ams: Any,
    private val cl: ClassLoader,
) {
    private val notes = LinkedHashMap<String, String>()

    fun report(): String = notes.entries.joinToString(", ") { "${it.key}=${it.value}" }

    private fun note(k: String, v: String) {
        notes[k] = v
    }

    private fun err(t: Throwable): String {
        val c = if (t is InvocationTargetException) (t.cause ?: t) else t
        return c.javaClass.simpleName
    }

    // ------------------------------------------------------------------ GameManager

    /** Set GAME_MODE_PERFORMANCE. Return mode sebelumnya untuk dikembalikan, atau null kalau tidak ada yang perlu dikembalikan. */
    fun applyGameMode(pkg: String): Int? {
        try {
            val gm = ctx.getSystemService("game")
            if (gm == null) {
                note("game_mode", "service-tidak-ada")
                return null
            }
            val prev = try {
                XposedHelpers.callMethod(gm, "getGameMode", pkg) as Int
            } catch (t: Throwable) {
                GAME_MODE_STANDARD // API baca tidak ada: asumsikan standar
            }
            if (prev == GAME_MODE_UNSUPPORTED) {
                note("game_mode", "app-bukan-kategori-game")
                return null
            }
            if (prev == GAME_MODE_PERFORMANCE) {
                note("game_mode", "sudah-performance")
                return null
            }
            XposedHelpers.callMethod(gm, "setGameMode", pkg, GAME_MODE_PERFORMANCE)
            note("game_mode", "ok")
            return prev
        } catch (t: Throwable) {
            note("game_mode", "gagal-${err(t)}")
            return null
        }
    }

    fun restoreGameMode(pkg: String, prev: Int) {
        try {
            val gm = ctx.getSystemService("game") ?: return
            XposedHelpers.callMethod(gm, "setGameMode", pkg, prev)
        } catch (t: Throwable) {
            note("game_mode_restore", "gagal-${err(t)}")
        }
    }

    // ------------------------------------------------------------------ Power HAL

    private val powerInternal: Any? by lazy {
        try {
            val pmi = XposedHelpers.findClass("android.os.PowerManagerInternal", cl)
            val ls = XposedHelpers.findClass("com.android.server.LocalServices", cl)
            XposedHelpers.callStaticMethod(ls, "getService", pmi)
        } catch (t: Throwable) {
            note("power_hal", "tidak-tersedia-${err(t)}")
            null
        }
    }

    private val modeGame: Int? by lazy { constant("android.hardware.power.Mode", "GAME") }
    private val modeGameLoading: Int? by lazy { constant("android.hardware.power.Mode", "GAME_LOADING") }
    private val boostInteraction: Int? by lazy { constant("android.hardware.power.Boost", "INTERACTION") }

    private fun constant(cls: String, field: String): Int? = try {
        XposedHelpers.getStaticIntField(XposedHelpers.findClass(cls, cl), field)
    } catch (t: Throwable) {
        null
    }

    fun setGamePower(on: Boolean) = setMode("power_game", modeGame, on)

    fun setGameLoading(on: Boolean) = setMode("power_loading", modeGameLoading, on)

    private fun setMode(key: String, mode: Int?, on: Boolean) {
        val p = powerInternal ?: return
        if (mode == null) {
            note(key, "mode-tidak-ada-di-HAL")
            return
        }
        try {
            XposedHelpers.callMethod(p, "setPowerMode", mode, on)
            note(key, "ok")
        } catch (t: Throwable) {
            note(key, "gagal-${err(t)}")
        }
    }

    fun interactionBoost(ms: Int) {
        val p = powerInternal ?: return
        val b = boostInteraction ?: return
        try {
            XposedHelpers.callMethod(p, "setPowerBoost", b, ms)
            note("power_boost", "ok")
        } catch (t: Throwable) {
            note("power_boost", "gagal-${err(t)}")
        }
    }

    // ------------------------------------------------------------------ Memori

    /** Compaction proses cache (bukan kill). Berjalan di thread background milik CachedAppOptimizer. */
    fun compact() {
        try {
            val oom = XposedHelpers.getObjectField(ams, "mOomAdjuster")
            val opt = XposedHelpers.getObjectField(oom, "mCachedAppOptimizer")
            XposedHelpers.callMethod(opt, "compactAllSystem")
            note("compact", "ok")
        } catch (t: Throwable) {
            note("compact", "gagal-${err(t)}")
        }
    }

    // ------------------------------------------------------------------ Refresh rate

    /** Kunci refresh rate minimum ke maksimum panel selama game. Nilai asli dibackup supaya aman kalau system_server crash. */
    fun forceRefreshRate(on: Boolean) {
        try {
            val cr = ctx.contentResolver
            if (on) {
                val max = maxRefreshRate()
                if (max == null) {
                    note("refresh", "mode-display-tidak-terbaca")
                    return
                }
                val backup = Settings.Global.getString(cr, BACKUP_KEY)
                if (backup.isNullOrEmpty()) {
                    val original = Settings.System.getFloat(cr, MIN_REFRESH_KEY, 0f)
                    Settings.Global.putString(cr, BACKUP_KEY, original.toString())
                }
                Settings.System.putFloat(cr, MIN_REFRESH_KEY, max)
                note("refresh", "ok-${max.toInt()}Hz")
            } else {
                recoverRefreshRate()
            }
        } catch (t: Throwable) {
            note("refresh", "gagal-${err(t)}")
        }
    }

    /** Dipanggil juga saat boot: kalau ada backup tersisa (crash sebelumnya), kembalikan. */
    fun recoverRefreshRate() {
        try {
            val cr = ctx.contentResolver
            val backup = Settings.Global.getString(cr, BACKUP_KEY)
            if (backup.isNullOrEmpty()) return
            val v = backup.toFloatOrNull()
            if (v != null) Settings.System.putFloat(cr, MIN_REFRESH_KEY, v)
            Settings.Global.putString(cr, BACKUP_KEY, "")
        } catch (t: Throwable) {
            note("refresh_restore", "gagal-${err(t)}")
        }
    }

    private fun maxRefreshRate(): Float? {
        val dm = ctx.getSystemService(DisplayManager::class.java) ?: return null
        val d = dm.getDisplay(Display.DEFAULT_DISPLAY) ?: return null
        val cur = d.mode
        var best = 0f
        for (m in d.supportedModes) {
            if (m.physicalWidth == cur.physicalWidth &&
                m.physicalHeight == cur.physicalHeight &&
                m.refreshRate > best
            ) {
                best = m.refreshRate
            }
        }
        return if (best > 0f) Math.round(best).toFloat() else null
    }

    companion object {
        private const val GAME_MODE_UNSUPPORTED = 0
        private const val GAME_MODE_STANDARD = 1
        private const val GAME_MODE_PERFORMANCE = 2
        private const val MIN_REFRESH_KEY = "min_refresh_rate"
        private const val BACKUP_KEY = "gamebooster_refresh_backup"
    }
}
