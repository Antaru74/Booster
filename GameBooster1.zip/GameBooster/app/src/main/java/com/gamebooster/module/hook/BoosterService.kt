package com.gamebooster.module.hook

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.PowerManager
import android.os.SystemClock
import android.util.Log
import com.gamebooster.module.Config
import com.gamebooster.module.Protocol
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers

/**
 * Otak module. Berjalan di dalam system_server.
 *
 *  OFF      -> module dimatikan dari app, semua dikembalikan.
 *  OVERALL  -> module aktif, tidak ada game di depan: boost transisi UI + housekeeping memori ringan.
 *  GAME     -> package terdaftar ada di depan: Game Mode, Power HAL, boost thread, compaction, (opsional) refresh rate.
 *
 * Semua perubahan dicatat dan dikembalikan saat game keluar / module dimatikan.
 */
class BoosterService(
    private val ctx: Context,
    ams: Any,
    private val cl: ClassLoader,
) {
    private val worker = HandlerThread("GameBooster").also { it.start() }
    private val handler = Handler(worker.looper)
    private val hints = SystemHints(ctx, ams, cl)
    private val threads = ThreadBooster()
    private val foreground = ForegroundResolver(ctx)

    @Volatile private var config = Config()
    @Volatile private var activeGame: String? = null
    @Volatile private var screenOn = true

    private var hooks = 0
    private var exitScheduled = false
    private var previousMode: Int? = null
    private var appliedPower = false
    private var appliedRefresh = false
    private var lastBoostAt = 0L
    private var lastHousekeepingAt = 0L
    private var lastLoadingPkg: String? = null
    private var lastLoadingAt = 0L
    private var lastPublished = ""

    // ------------------------------------------------------------------ Runnables

    private val evalRunnable = Runnable { evaluate() }

    private val exitRunnable = Runnable {
        exitScheduled = false
        try {
            val top = foreground.topPackage()
            val stillGame = screenOn && top != null && top == activeGame
            if (!stillGame) {
                leaveGame()
                publish(false)
            }
        } catch (t: Throwable) {
            fail("exit", t)
        }
    }

    private val compactRunnable = Runnable {
        if (activeGame != null) hints.compact()
    }

    private val loadingOff = Runnable { hints.setGameLoading(false) }

    private val threadTick = object : Runnable {
        override fun run() {
            val g = activeGame ?: return
            if (!config.threadBoost) return
            try {
                val pids = foreground.pidsOf(g)
                if (pids.isNotEmpty()) threads.sample(pids)
            } catch (t: Throwable) {
                fail("thread", t)
            }
            handler.postDelayed(this, THREAD_TICK_MS)
        }
    }

    /** Cadangan kalau hook task-stack tidak ketemu di ROM ini. */
    private val poll = object : Runnable {
        override fun run() {
            if (config.enabled && screenOn) evaluate()
            handler.postDelayed(this, 2_000L)
        }
    }

    // ------------------------------------------------------------------ Receivers

    private val configReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            try {
                when (i.action) {
                    Protocol.ACTION_SET_CONFIG ->
                        applyConfig(Config.fromJson(i.getStringExtra(Protocol.EXTRA_CONFIG)))
                    Protocol.ACTION_QUERY -> publish(true)
                }
            } catch (t: Throwable) {
                fail("config", t)
            }
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            try {
                screenOn = i.action != Intent.ACTION_SCREEN_OFF
                if (!screenOn) scheduleHousekeeping()
                evaluate()
            } catch (t: Throwable) {
                fail("screen", t)
            }
        }
    }

    // ------------------------------------------------------------------ Lifecycle

    fun start() {
        handler.post {
            try {
                hints.recoverRefreshRate()
                config = ConfigStore.load(ctx)
                screenOn = ctx.getSystemService(PowerManager::class.java)?.isInteractive ?: true
                registerReceivers()
                installTaskHooks()
                evaluate()
                Log.i(TAG, "aktif: hooks=$hooks config=${config.toJson()}")
            } catch (t: Throwable) {
                fail("start", t)
            }
        }
    }

    private fun registerReceivers() {
        val cfg = IntentFilter().apply {
            addAction(Protocol.ACTION_SET_CONFIG)
            addAction(Protocol.ACTION_QUERY)
        }
        register(configReceiver, cfg, Protocol.PERMISSION, true)

        val scr = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        register(screenReceiver, scr, null, false)
    }

    private fun register(r: BroadcastReceiver, f: IntentFilter, perm: String?, exported: Boolean) {
        if (Build.VERSION.SDK_INT >= 33) {
            val flag = if (exported) Context.RECEIVER_EXPORTED else Context.RECEIVER_NOT_EXPORTED
            ctx.registerReceiver(r, f, perm, handler, flag)
        } else {
            ctx.registerReceiver(r, f, perm, handler)
        }
    }

    private fun installTaskHooks() {
        val hook = object : XC_MethodHook() {
            override fun afterHookedMethod(param: XC_MethodHook.MethodHookParam) {
                requestEvaluate() // hanya post ke handler: sangat ringan
            }
        }
        try {
            val c = XposedHelpers.findClass("com.android.server.wm.TaskChangeNotificationController", cl)
            for (name in arrayOf("notifyTaskStackChanged", "notifyTaskMovedToFront")) {
                hooks += XposedBridge.hookAllMethods(c, name, hook).size
            }
        } catch (t: Throwable) {
            fail("hook", t)
        }
        if (hooks == 0) {
            Log.w(TAG, "hook task-stack tidak ketemu, pakai polling 2 detik")
            handler.postDelayed(poll, 2_000L)
        }
    }

    private fun requestEvaluate() {
        if (!config.enabled && activeGame == null) return
        handler.removeCallbacks(evalRunnable)
        handler.postDelayed(evalRunnable, 250L)
    }

    // ------------------------------------------------------------------ Config

    private fun applyConfig(newCfg: Config) {
        val old = config
        config = newCfg
        ConfigStore.save(ctx, newCfg)
        // Kalau opsi berubah saat game berjalan: lepas dulu, evaluate() akan pasang ulang dengan opsi baru.
        if (activeGame != null && old != newCfg) leaveGame()
        evaluate()
        publish(true)
    }

    // ------------------------------------------------------------------ Core

    private fun evaluate() {
        try {
            val cfg = config
            if (!cfg.enabled) {
                cancelExit()
                leaveGame()
                publish(false)
                return
            }

            val top = foreground.topPackage()
            if (top == null) {
                publish(false)
                return
            }

            val game = if (screenOn && top in cfg.packages) top else null
            val active = activeGame

            if (game != null) {
                cancelExit()
                if (active != game) {
                    if (active != null) leaveGame()
                    enterGame(game)
                }
            } else if (active != null) {
                scheduleExit()
            } else if (screenOn && cfg.uiBoost) {
                uiBoost()
            }
            publish(false)
        } catch (t: Throwable) {
            fail("evaluate", t)
        }
    }

    private fun scheduleExit() {
        if (exitScheduled) return
        exitScheduled = true
        handler.postDelayed(exitRunnable, EXIT_GRACE_MS)
    }

    private fun cancelExit() {
        if (!exitScheduled) return
        exitScheduled = false
        handler.removeCallbacks(exitRunnable)
    }

    private fun enterGame(pkg: String) {
        val cfg = config
        activeGame = pkg
        Log.i(TAG, "game masuk: $pkg")

        previousMode = if (cfg.gameMode) hints.applyGameMode(pkg) else null

        if (cfg.powerHint) {
            hints.setGamePower(true)
            appliedPower = true
            val now = SystemClock.elapsedRealtime()
            if (pkg != lastLoadingPkg || now - lastLoadingAt > 120_000L) {
                lastLoadingPkg = pkg
                lastLoadingAt = now
                hints.setGameLoading(true)
                handler.postDelayed(loadingOff, 12_000L)
            }
            hints.interactionBoost(2_000)
        }

        if (cfg.refreshRate) {
            hints.forceRefreshRate(true)
            appliedRefresh = true
        }

        if (cfg.memory) handler.postDelayed(compactRunnable, 1_500L)

        if (cfg.threadBoost) {
            threads.reset()
            handler.removeCallbacks(threadTick)
            handler.postDelayed(threadTick, 3_000L)
        }
    }

    private fun leaveGame() {
        val g = activeGame ?: return
        handler.removeCallbacks(threadTick)
        handler.removeCallbacks(compactRunnable)
        handler.removeCallbacks(loadingOff)

        threads.restoreAll()
        previousMode?.let { hints.restoreGameMode(g, it) }
        previousMode = null

        if (appliedPower) {
            hints.setGameLoading(false)
            hints.setGamePower(false)
            appliedPower = false
        }
        if (appliedRefresh) {
            hints.forceRefreshRate(false)
            appliedRefresh = false
        }

        activeGame = null
        Log.i(TAG, "game keluar: $g")

        // Transisi balik ke UI: kasih dorongan singkat supaya langsung responsif.
        if (config.enabled && config.uiBoost) hints.interactionBoost(1_500)
    }

    private fun uiBoost() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastBoostAt < 1_000L) return
        lastBoostAt = now
        hints.interactionBoost(1_200)
    }

    private fun scheduleHousekeeping() {
        val cfg = config
        if (!cfg.enabled || !cfg.memory) return
        val now = SystemClock.elapsedRealtime()
        if (lastHousekeepingAt != 0L && now - lastHousekeepingAt < HOUSEKEEP_INTERVAL_MS) return
        handler.postDelayed({
            if (!screenOn && config.enabled && config.memory && activeGame == null) {
                lastHousekeepingAt = SystemClock.elapsedRealtime()
                hints.compact()
            }
        }, 15_000L)
    }

    // ------------------------------------------------------------------ Status ke app

    private fun publish(force: Boolean) {
        val cfg = config
        val game = activeGame
        val profile = when {
            !cfg.enabled -> Protocol.PROFILE_OFF
            game != null -> Protocol.PROFILE_GAME
            else -> Protocol.PROFILE_OVERALL
        }
        val json = cfg.toJson()
        val sig = "$profile|$game|$json"
        if (!force && sig == lastPublished) return
        lastPublished = sig
        try {
            val i = Intent(Protocol.ACTION_STATUS)
                .setPackage(Protocol.MODULE_PACKAGE)
                .putExtra(Protocol.EXTRA_PROFILE, profile)
                .putExtra(Protocol.EXTRA_GAME, game)
                .putExtra(Protocol.EXTRA_CONFIG, json)
                .putExtra(Protocol.EXTRA_NOTES, "hooks=$hooks, boosted=${threads.boostedCount()}, ${hints.report()}")
            ctx.sendBroadcast(i)
        } catch (t: Throwable) {
            fail("publish", t)
        }
    }

    private fun fail(where: String, t: Throwable) {
        Log.e(TAG, where, t)
        XposedBridge.log("[GameBooster] $where: $t")
    }

    companion object {
        private const val TAG = "GameBooster"
        private const val EXIT_GRACE_MS = 2_500L
        private const val THREAD_TICK_MS = 15_000L
        private const val HOUSEKEEP_INTERVAL_MS = 30L * 60L * 1000L
    }
}
