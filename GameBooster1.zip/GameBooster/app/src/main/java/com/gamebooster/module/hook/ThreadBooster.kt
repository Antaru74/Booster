package com.gamebooster.module.hook

import android.os.Process
import android.os.SystemClock
import java.io.File

/**
 * Menaikkan prioritas (nice) thread game yang benar-benar sibuk / thread render.
 *
 * Aturan aman:
 *  - hanya MENAIKKAN prioritas (tidak pernah menurunkan thread yang sudah lebih tinggi);
 *  - thread yang sengaja diset background oleh game (nice >= 10) tidak disentuh;
 *  - maksimal [MAX_THREADS] thread;
 *  - semua perubahan dicatat dan dikembalikan saat game ditutup.
 *
 * system_server punya CAP_SYS_NICE, jadi setThreadPriority() ke proses lain diizinkan SELinux.
 */
class ThreadBooster {
    private class Applied(val original: Int, val applied: Int)

    private val applied = HashMap<Int, Applied>()
    private var prevJiffies = HashMap<Int, Long>()
    private var prevAt = 0L

    fun reset() {
        applied.clear()
        prevJiffies = HashMap()
        prevAt = 0L
    }

    fun boostedCount(): Int = applied.size

    /** Dipanggil berkala. Pemanggilan pertama hanya mengambil baseline CPU. */
    fun sample(pids: List<Int>) {
        val now = SystemClock.elapsedRealtime()
        val cur = HashMap<Int, Long>()
        val names = HashMap<Int, String>()

        for (pid in pids) {
            val tids = File("/proc/$pid/task").list() ?: continue
            for (s in tids) {
                val tid = s.toIntOrNull() ?: continue
                val st = readStat(pid, tid) ?: continue
                names[tid] = st.first
                cur[tid] = st.second
            }
        }

        val dt = now - prevAt
        for ((tid, jiffies) in cur) {
            val name = names[tid] ?: continue
            var target: Int? = null

            if (NAME_RE.matches(name)) {
                target = NICE_HOT
            } else if (prevAt > 0L && dt > 500L) {
                val before = prevJiffies[tid]
                if (before != null) {
                    // 1 jiffy = 10 ms (USER_HZ = 100)
                    val frac = (jiffies - before) * 10.0 / dt
                    target = when {
                        frac >= 0.30 -> NICE_HOT
                        frac >= 0.12 -> NICE_WARM
                        else -> null
                    }
                }
            }
            if (target != null) boost(tid, target)
        }

        prevJiffies = cur
        prevAt = now
    }

    private fun boost(tid: Int, target: Int) {
        try {
            val known = applied[tid]
            if (known == null && applied.size >= MAX_THREADS) return
            val current = Process.getThreadPriority(tid)
            if (current >= 10) return          // game sengaja menaruhnya di background
            if (current <= target) return      // sudah sama / lebih tinggi
            Process.setThreadPriority(tid, target)
            applied[tid] = Applied(known?.original ?: current, target)
        } catch (t: Throwable) {
            // thread sudah mati / ditolak: abaikan
        }
    }

    fun restoreAll() {
        for ((tid, a) in applied) {
            try {
                if (Process.getThreadPriority(tid) == a.applied) {
                    Process.setThreadPriority(tid, a.original)
                }
            } catch (t: Throwable) {
                // thread sudah tidak ada
            }
        }
        reset()
    }

    /** Return (nama thread, utime+stime dalam jiffies). */
    private fun readStat(pid: Int, tid: Int): Pair<String, Long>? {
        return try {
            val s = File("/proc/$pid/task/$tid/stat").readText()
            val l = s.indexOf('(')
            val r = s.lastIndexOf(')')
            if (l < 0 || r < l) return null
            val comm = s.substring(l + 1, r)
            val f = s.substring(r + 2).split(' ')
            Pair(comm, f[11].toLong() + f[12].toLong())
        } catch (t: Throwable) {
            null
        }
    }

    companion object {
        private const val NICE_HOT = -8   // THREAD_PRIORITY_URGENT_DISPLAY
        private const val NICE_WARM = -4  // THREAD_PRIORITY_DISPLAY
        private const val MAX_THREADS = 12

        // Nama thread kritis engine umum (Unity, Unreal, GL/Vulkan, Mali). Nama Linux max 15 karakter.
        private val NAME_RE = Regex(
            "^(RenderThread|UnityMain|UnityGfxDevice.*|UnityMultiRende.*|GameThread|RHIThread|" +
                "RenderingThread.*|GLThread.*|mali-.*)$"
        )
    }
}
