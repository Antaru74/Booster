package com.gamebooster.module.ui

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import com.gamebooster.module.Config
import com.gamebooster.module.Protocol
import com.gamebooster.module.R
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.color.DynamicColors
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvDetail: TextView
    private lateinit var swEnabled: MaterialSwitch
    private lateinit var swGameMode: MaterialSwitch
    private lateinit var swPower: MaterialSwitch
    private lateinit var swThreads: MaterialSwitch
    private lateinit var swMemory: MaterialSwitch
    private lateinit var swUi: MaterialSwitch
    private lateinit var swRefresh: MaterialSwitch
    private lateinit var etPackage: TextInputEditText
    private lateinit var chips: ChipGroup

    private var config = Config()
    private var rendering = false
    private var connected = false
    private var lastPushAt = 0L
    private val ui = Handler(Looper.getMainLooper())

    private val noReply = Runnable {
        if (!connected) {
            tvStatus.text = "Module belum aktif"
            tvDetail.text = "Aktifkan GameBooster di LSPosed (scope: System Framework), lalu reboot."
        }
    }

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) = onStatus(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        DynamicColors.applyToActivityIfAvailable(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val root = findViewById<View>(R.id.root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            v.updatePadding(left = b.left, top = b.top, right = b.right, bottom = b.bottom)
            WindowInsetsCompat.CONSUMED
        }

        tvStatus = findViewById(R.id.tvStatus)
        tvDetail = findViewById(R.id.tvDetail)
        swEnabled = findViewById(R.id.swEnabled)
        swGameMode = findViewById(R.id.swGameMode)
        swPower = findViewById(R.id.swPower)
        swThreads = findViewById(R.id.swThreads)
        swMemory = findViewById(R.id.swMemory)
        swUi = findViewById(R.id.swUi)
        swRefresh = findViewById(R.id.swRefresh)
        etPackage = findViewById(R.id.etPackage)
        chips = findViewById(R.id.chipGroup)

        // Cache lokal, sekadar supaya UI tidak kosong sebelum status dari system_server datang.
        config = Config.fromJson(getSharedPreferences("cache", MODE_PRIVATE).getString("config", null))

        swEnabled.setOnCheckedChangeListener { _, v -> change { it.copy(enabled = v) } }
        swGameMode.setOnCheckedChangeListener { _, v -> change { it.copy(gameMode = v) } }
        swPower.setOnCheckedChangeListener { _, v -> change { it.copy(powerHint = v) } }
        swThreads.setOnCheckedChangeListener { _, v -> change { it.copy(threadBoost = v) } }
        swMemory.setOnCheckedChangeListener { _, v -> change { it.copy(memory = v) } }
        swUi.setOnCheckedChangeListener { _, v -> change { it.copy(uiBoost = v) } }
        swRefresh.setOnCheckedChangeListener { _, v -> change { it.copy(refreshRate = v) } }

        findViewById<Button>(R.id.btnAdd).setOnClickListener { addPackage() }
        findViewById<Button>(R.id.btnPick).setOnClickListener { pickApps() }
        etPackage.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                addPackage()
                true
            } else {
                false
            }
        }

        render()
    }

    override fun onStart() {
        super.onStart()
        ContextCompat.registerReceiver(
            this,
            statusReceiver,
            IntentFilter(Protocol.ACTION_STATUS),
            Protocol.PERMISSION,
            null,
            ContextCompat.RECEIVER_EXPORTED,
        )
        connected = false
        tvStatus.text = "Memeriksa module…"
        tvDetail.text = ""
        sendBroadcast(Intent(Protocol.ACTION_QUERY), Protocol.PERMISSION)
        ui.postDelayed(noReply, 1_500L)
    }

    override fun onStop() {
        ui.removeCallbacks(noReply)
        unregisterReceiver(statusReceiver)
        super.onStop()
    }

    // ------------------------------------------------------------------ State

    private fun change(block: (Config) -> Config) {
        if (rendering) return
        config = block(config)
        push()
    }

    private fun push() {
        lastPushAt = SystemClock.elapsedRealtime()
        val json = config.toJson()
        getSharedPreferences("cache", MODE_PRIVATE).edit().putString("config", json).apply()
        sendBroadcast(
            Intent(Protocol.ACTION_SET_CONFIG).putExtra(Protocol.EXTRA_CONFIG, json),
            Protocol.PERMISSION,
        )
    }

    private fun onStatus(i: Intent) {
        connected = true
        ui.removeCallbacks(noReply)

        // Abaikan config dari system sesaat setelah kita sendiri mengubah, supaya switch tidak "loncat balik".
        if (SystemClock.elapsedRealtime() - lastPushAt > 800L) {
            config = Config.fromJson(i.getStringExtra(Protocol.EXTRA_CONFIG))
            render()
        }

        val game = i.getStringExtra(Protocol.EXTRA_GAME)
        tvStatus.text = when (i.getStringExtra(Protocol.EXTRA_PROFILE)) {
            Protocol.PROFILE_GAME -> "Mode GAME aktif: $game"
            Protocol.PROFILE_OVERALL -> "Mode OVERALL aktif"
            else -> "Module terhubung · optimasi OFF"
        }
        tvDetail.text = i.getStringExtra(Protocol.EXTRA_NOTES).orEmpty()
    }

    private fun render() {
        rendering = true
        swEnabled.isChecked = config.enabled
        swGameMode.isChecked = config.gameMode
        swPower.isChecked = config.powerHint
        swThreads.isChecked = config.threadBoost
        swMemory.isChecked = config.memory
        swUi.isChecked = config.uiBoost
        swRefresh.isChecked = config.refreshRate

        chips.removeAllViews()
        for (pkg in config.packages.sorted()) {
            val chip = Chip(this)
            chip.text = pkg
            chip.isCloseIconVisible = true
            chip.setOnCloseIconClickListener {
                config = config.copy(packages = config.packages - pkg)
                render()
                push()
            }
            chips.addView(chip)
        }
        rendering = false
    }

    // ------------------------------------------------------------------ Daftar game

    private fun addPackage() {
        val s = etPackage.text?.toString()?.trim().orEmpty()
        if (!Config.isValidPackage(s)) {
            Toast.makeText(this, "Package name tidak valid", Toast.LENGTH_SHORT).show()
            return
        }
        config = config.copy(packages = config.packages + s)
        etPackage.setText("")
        render()
        push()
    }

    private fun pickApps() {
        val pm = packageManager
        val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launch, 0)
            .map { it.activityInfo.applicationInfo }
            .distinctBy { it.packageName }
            .filter { it.packageName != packageName }
            .sortedWith(
                compareByDescending<ApplicationInfo> { it.category == ApplicationInfo.CATEGORY_GAME }
                    .thenBy { pm.getApplicationLabel(it).toString().lowercase() }
            )

        val labels = apps.map {
            val l = pm.getApplicationLabel(it).toString()
            if (it.category == ApplicationInfo.CATEGORY_GAME) "🎮 $l" else l
        }.toTypedArray()
        val checked = BooleanArray(apps.size) { apps[it].packageName in config.packages }
        val pending = HashSet(config.packages)

        MaterialAlertDialogBuilder(this)
            .setTitle("Pilih game / aplikasi")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked ->
                val p = apps[which].packageName
                if (isChecked) pending.add(p) else pending.remove(p)
            }
            .setPositiveButton("Simpan") { _, _ ->
                config = config.copy(packages = pending)
                render()
                push()
            }
            .setNegativeButton("Batal", null)
            .show()
    }
}
