package com.gamebooster.module.hook

import android.content.Context
import android.provider.Settings
import android.util.Log
import com.gamebooster.module.Config

/** Config disimpan system_server di Settings.Global supaya bertahan setelah reboot. */
object ConfigStore {
    private const val KEY = "gamebooster_config"

    fun load(ctx: Context): Config = try {
        Config.fromJson(Settings.Global.getString(ctx.contentResolver, KEY))
    } catch (t: Throwable) {
        Config()
    }

    fun save(ctx: Context, c: Config) {
        try {
            Settings.Global.putString(ctx.contentResolver, KEY, c.toJson())
        } catch (t: Throwable) {
            Log.e("GameBooster", "simpan config gagal", t)
        }
    }
}
