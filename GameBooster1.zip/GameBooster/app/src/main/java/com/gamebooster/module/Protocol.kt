package com.gamebooster.module

import org.json.JSONArray
import org.json.JSONObject

/** Kontrak komunikasi antara app UI dan system_server (lewat broadcast bertanda tangan). */
object Protocol {
    const val MODULE_PACKAGE = "com.gamebooster.module"
    const val PERMISSION = "com.gamebooster.module.permission.CONFIGURE"

    const val ACTION_SET_CONFIG = "com.gamebooster.module.action.SET_CONFIG"
    const val ACTION_QUERY = "com.gamebooster.module.action.QUERY"
    const val ACTION_STATUS = "com.gamebooster.module.action.STATUS"

    const val EXTRA_CONFIG = "config"
    const val EXTRA_PROFILE = "profile"
    const val EXTRA_GAME = "game"
    const val EXTRA_NOTES = "notes"

    const val PROFILE_OFF = "off"
    const val PROFILE_OVERALL = "overall"
    const val PROFILE_GAME = "game"
}

data class Config(
    val enabled: Boolean = false,
    val packages: Set<String> = emptySet(),
    val gameMode: Boolean = true,
    val powerHint: Boolean = true,
    val threadBoost: Boolean = true,
    val memory: Boolean = true,
    val uiBoost: Boolean = true,
    val refreshRate: Boolean = false,
) {
    fun toJson(): String {
        val o = JSONObject()
        o.put("enabled", enabled)
        o.put("packages", JSONArray(packages.sorted()))
        o.put("gameMode", gameMode)
        o.put("powerHint", powerHint)
        o.put("threadBoost", threadBoost)
        o.put("memory", memory)
        o.put("uiBoost", uiBoost)
        o.put("refreshRate", refreshRate)
        return o.toString()
    }

    companion object {
        private val PACKAGE_REGEX = Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$")

        fun isValidPackage(s: String): Boolean = PACKAGE_REGEX.matches(s)

        fun fromJson(json: String?): Config {
            if (json.isNullOrEmpty()) return Config()
            return try {
                val o = JSONObject(json)
                val arr = o.optJSONArray("packages")
                val pk = LinkedHashSet<String>()
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        val s = arr.optString(i).trim()
                        if (isValidPackage(s)) pk.add(s)
                    }
                }
                Config(
                    enabled = o.optBoolean("enabled", false),
                    packages = pk,
                    gameMode = o.optBoolean("gameMode", true),
                    powerHint = o.optBoolean("powerHint", true),
                    threadBoost = o.optBoolean("threadBoost", true),
                    memory = o.optBoolean("memory", true),
                    uiBoost = o.optBoolean("uiBoost", true),
                    refreshRate = o.optBoolean("refreshRate", false),
                )
            } catch (t: Throwable) {
                Config()
            }
        }
    }
}
