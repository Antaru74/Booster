package com.gamebooster.module.hook

import android.app.ActivityManager
import android.content.Context

/** Memakai API publik (dipanggil dari system_server, jadi punya izin penuh) supaya tahan antar versi. */
class ForegroundResolver(ctx: Context) {
    private val am: ActivityManager? = ctx.getSystemService(ActivityManager::class.java)

    /** Package di task paling atas, atau null kalau tidak diketahui. */
    @Suppress("DEPRECATION")
    fun topPackage(): String? = try {
        am?.getRunningTasks(1)?.firstOrNull()?.topActivity?.packageName
    } catch (t: Throwable) {
        null
    }

    /** Semua PID proses milik [pkg] (game multi-proses ikut terhitung). */
    fun pidsOf(pkg: String): List<Int> = try {
        am?.runningAppProcesses.orEmpty()
            .filter { p -> p.pkgList?.contains(pkg) == true }
            .map { it.pid }
    } catch (t: Throwable) {
        emptyList()
    }
}
