package com.gamebooster.module.hook

import android.content.Context
import android.util.Log
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Menunggu ActivityManagerService siap, baru menyalakan BoosterService.
 * Semua kerja berat terjadi SETELAH boot selesai, jadi module ini tidak bisa bikin bootloop
 * lewat jalur startup.
 */
object Bootstrap {
    private const val TAG = "GameBooster"
    private val started = AtomicBoolean(false)

    fun install(cl: ClassLoader) {
        val amsClass = XposedHelpers.findClass("com.android.server.am.ActivityManagerService", cl)
        val hook = object : XC_MethodHook() {
            override fun afterHookedMethod(param: XC_MethodHook.MethodHookParam) {
                start(param.thisObject, cl)
            }
        }
        // hookAllMethods: toleran terhadap perubahan signature antar versi Android / ROM.
        val n = XposedBridge.hookAllMethods(amsClass, "systemReady", hook).size +
            XposedBridge.hookAllMethods(amsClass, "finishBooting", hook).size
        Log.i(TAG, "Bootstrap terpasang ($n hook)")
    }

    private fun start(ams: Any, cl: ClassLoader) {
        if (!started.compareAndSet(false, true)) return
        try {
            val ctx = XposedHelpers.getObjectField(ams, "mContext") as Context
            BoosterService(ctx, ams, cl).start()
        } catch (t: Throwable) {
            Log.e(TAG, "start gagal", t)
            XposedBridge.log("[GameBooster] start gagal: $t")
        }
    }
}
